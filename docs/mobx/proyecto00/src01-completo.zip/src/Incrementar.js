import React, { Component } from 'react';
import instanciaData from './Data';

class Incrementar extends Component{

	consola(){
		console.log(instanciaData);
	}


	/*<div>	
				<button onClick={this.consola.bind(this)}> Consola </button>
				<button onClick={
					function(){
						{instanciaData.sumar1()}
					}
				}
				>Incrementar </button>
			</div>
			*/


	render(){
		return(
				<button onClick={
					function(){
						{instanciaData.sumar1()}
					}
				}
				>Incrementar </button>
			)
		}
}

export default Incrementar;