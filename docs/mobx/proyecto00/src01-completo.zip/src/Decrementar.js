import React, { Component } from 'react';
import instanciaData from './Data';


class Decrementar extends Component{
	render(){
		return(
			<button onClick={
					function(){
						{instanciaData.restar1()}
					}
				}
				>Decrementar </button>
			)
		}
}

export default Decrementar;