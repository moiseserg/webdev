import React, { Component } from 'react';
import { observer } from 'mobx-react'

import instanciaData from './Data';
import Incrementar from './Incrementar';
import Decrementar from './Decrementar';

class Principal extends Component{
  render(){
    return(
    	<div>
	        <h1> Estoy en principal </h1>
	        <p> Valor: {instanciaData.numero} </p>
	        <Incrementar/>
	        <Decrementar/>
        </div>
      )
  }
}
//para poder ser observado el componente desde afuera
export default observer(Principal);