import { extendObservable } from 'mobx';

class Data {
	constructor(){
		extendObservable(
			this, 
			{numero: 0}
			);
	}

	sumar1(){
		this.numero = this.numero+1;
	}
	restar1(){
		this.numero = this.numero-1;
	}
}

var instanciaData = new Data();
export default instanciaData;

