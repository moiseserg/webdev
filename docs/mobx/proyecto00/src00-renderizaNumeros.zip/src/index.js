import React from 'react';
import ReactDOM from 'react-dom';
import Principal from './Principal';
import './index.css';

ReactDOM.render(
  <Principal/>,
  document.getElementById('root')
);
