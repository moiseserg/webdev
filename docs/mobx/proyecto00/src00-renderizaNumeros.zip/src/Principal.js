import React, { Component } from 'react';
import instanciaData from './Data';

class Principal extends Component{
  render(){
    return(
    	<div>
	        <h1> Estoy en principal </h1>
	        <p> Valor: {instanciaData.numero} </p>
        </div>
      )
  }
}
//para poder ser observado el componente desde afuera
export default Principal;