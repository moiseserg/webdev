import { extendObservable } from 'mobx';

class Data {
	constructor(){
		extendObservable(
			this, 
			{numero: 0}
			);
	}
}

var instanciaData = new Data;
export default instanciaData;

	